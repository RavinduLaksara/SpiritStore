## Running an example

From the examples folder, run:
`php your_example.php`

e.g.

`php ThinEventWebhookHandler.php`

## Adding a new example

1. Clone ExampleTemplate.php
2. Implement your example
3. Fill out the file comment. Include a description and key steps that are being demonstrated.
4. Run it (as per above)
5. 👍
